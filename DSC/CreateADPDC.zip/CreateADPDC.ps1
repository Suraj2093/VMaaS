configuration CreateADPDC
{ 
	  param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$WindowsOS,


        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )

If ($WindowsOS -eq '2012-R2-Datacenter') 
{
  $fnlevel="Win2012R2"
} 
 Else 
{
  $fnlevel="7"
} 

Get-WindowsFeature AD-Domain-Services | Install-WindowsFeature
Import-Module ADDSDeployment
$ADRestorePassword="demopassword1!"
# Variables
$NetBIOSName = $DomainName.Split(".") | Select -First 1
$ForestMode = $fnlevel
$DomainMode = $fnlevel
$DatabasePath = "C:\ADDS\NTDS"
$SYSVOLPath = "C:\ADDS\SYSVOL"
$LogPath = "C:\ADDS\Logs"
$RestorePassword = ConvertTo-SecureString -String $ADRestorePassword -AsPlainText -Force
# Install Required Windows Features
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools
# Create AD Domain
$ADinstall= Install-ADDSForest -DomainName $DomainName `
                   -DomainNetbiosName $NetBIOSName `
                   -ForestMode $ForestMode `
                   -DomainMode $DomainMode `
                   -InstallDns:$true `
                   -DatabasePath $DatabasePath `
                   -SYSVOLPath $SYSVOLPath `
                   -LogPath $LogPath `
                   -SafeModeAdministratorPassword $RestorePassword `
                   -NoRebootonCompletion:$false `
                   -Force:$true 
Restart-Computer 
New-Item c:\new_file.txt -type file
$string = $DomainName
$netbios,$extension = $string.split('.')
Add-Content c:\new_file.txt $string
Add-Content c:\new_file.txt $netbios
Add-Content c:\new_file.txt $extension
$a= "CN=Users,dc=$netbios,dc=$extension"
Add-Content c:\new_file.txt $a
Get-ADUser -Filter * -SearchBase $a -Properties userPrincipalName | foreach { Set-ADUser $_ -UserPrincipalName "$($_.samaccountname)@$netbios.org"}

Add-WindowsFeature ServerEssentialsRole
Add-Content c:\new_file.txt "status1"
[System.Management.Automation.PSCredential ]$creds = New-Object System.Management.Automation.PSCredential ($Admincreds.UserName, $Admincreds.Password)
#$cred = New-Object -typename System.Management.Automation.PSCredential -argumentlist $username, $SecurePassword
Add-Content c:\new_file.txt "status2"
Start-WssConfigurationService -Credential $cred -Force
Add-Content c:\new_file.txt "status3"


}

