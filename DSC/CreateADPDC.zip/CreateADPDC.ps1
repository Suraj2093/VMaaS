configuration CreateADPDC
{ 
	  param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$WindowsOS,


        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    )

If ($WindowsOS -eq '2012-R2-Datacenter') 
{
  $fnlevel="Win2012R2"
} 
 Else 
{
  $fnlevel="7"
} 

Get-WindowsFeature AD-Domain-Services | Install-WindowsFeature
Import-Module ADDSDeployment
$ADRestorePassword="demopassword1!"
# Variables
$NetBIOSName = $DomainName.Split(".") | Select -First 1
$ForestMode = $fnlevel
$DomainMode = $fnlevel
$DatabasePath = "C:\ADDS\NTDS"
$SYSVOLPath = "C:\ADDS\SYSVOL"
$LogPath = "C:\ADDS\Logs"
$RestorePassword = ConvertTo-SecureString -String $ADRestorePassword -AsPlainText -Force
# Install Required Windows Features
Install-WindowsFeature AD-Domain-Services -IncludeManagementTools
# Create AD Domain
$ADinstall= Install-ADDSForest -DomainName $DomainName `
                   -DomainNetbiosName $NetBIOSName `
                   -ForestMode $ForestMode `
                   -DomainMode $DomainMode `
                   -InstallDns:$true `
                   -DatabasePath $DatabasePath `
                   -SYSVOLPath $SYSVOLPath `
                   -LogPath $LogPath `
                   -SafeModeAdministratorPassword $RestorePassword `
                   -NoRebootonCompletion:$false `
                   -Force:$true 
Restart-Computer 
Get-WindowsFeature -Name AD-Certificate | Install-WindowsFeature
}

